# تعليم القيادة - نسخة APK تجريبية (بدون Firebase/Maps)

دي حزمة سريعة علشان تقدر تشوف **شكل البرنامج** من غير إعدادات Firebase أو Google Maps.
هتلاقي شاشات: Splash, Welcome, Login, Register, اختيار الدور، شاشة الطالب، إنشاء طلب، الملف الشخصي… إلخ.

## طريقة التشغيل والبناء (Android APK)

1) ثبّت Flutter و Android Studio (وشغّل `flutter doctor` لحد ما يكون كله OK).
2) اعمل مشروع فاضي:
   ```bash
   flutter create driving_learn
   ```
3) فكّ ضغط الملفات دي فوق المشروع (وافق على الاستبدال):
   - انسخ `lib/main.dart`
   - انسخ مجلد `assets/`
   - انسخ `pubspec.yaml`
4) نفّذ:
   ```bash
   cd driving_learn
   flutter pub get
   flutter run    # جرِّب على جهاز/محاكي
   ```
5) بناء APK سريع (Debug):
   ```bash
   flutter build apk --debug
   ```
   الملف هتلاقيه في:
   `build/app/outputs/flutter-apk/app-debug.apk`

> ملاحظة: النسخة دي **بدون** Firebase و Google Maps علشان ما تحتاجش مفاتيح API أو إعدادات. لما تحب تنتقل للنسخة الكاملة ابعتلي مفاتيحك وأنا أظبطلك الإعداد.

## تغييرات عن الكود الأصلي
- شلت Firebase/Maps/Toast/Spinner عشان نبني من غير إعدادات.
- استخدمت `ColorScheme.fromSeed` بدل `accentColor`.
- ضفت Placeholders للشاشات الناقصة (Trainer/Orders/Chat/Settings).
- خريطه Placeholder بدل Google Map.

بالتوفيق! ✌️
