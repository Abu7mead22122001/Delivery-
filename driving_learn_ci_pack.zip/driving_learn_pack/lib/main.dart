
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:async';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => OrderProvider()),
      ],
      child: MaterialApp(
        title: 'تعليم القيادة (Demo)',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0D47A1)),
          scaffoldBackgroundColor: Colors.grey[100],
          appBarTheme: const AppBarTheme(
            elevation: 0,
            titleTextStyle: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ),
        initialRoute: '/splash',
        routes: {
          '/splash': (context) => const SplashScreen(),
          '/welcome': (context) => const WelcomeScreen(),
          '/login': (context) => const LoginScreen(),
          '/register': (context) => const RegisterScreen(),
          '/role_selection': (context) => const RoleSelectionScreen(),
          '/learner_home': (context) => const LearnerHomeScreen(),
          '/trainer_home': (context) => const TrainerHomeScreen(),
          '/learner_create_order': (context) => const LearnerCreateOrderScreen(),
          '/trainer_orders': (context) => const TrainerOrdersScreen(),
          '/order_detail': (context) => const OrderDetailScreen(),
          '/profile': (context) => const ProfileScreen(),
          '/settings': (context) => const SettingsScreen(),
          '/chat': (context) => const ChatScreen(),
        },
        debugShowCheckedModeBanner: false,
      ),
    );
  }
}

// ************************** Splash **************************
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 2), () {
      if (mounted) Navigator.pushReplacementNamed(context, '/welcome');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/logo.png', width: 150, height: 150),
            const SizedBox(height: 30),
            const CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }
}

// ************************** Welcome **************************
class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/welcome_bg.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Container(color: Colors.black.withOpacity(0.5)),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'أهلا بيك في تطبيق تعليم القيادة (نسخة معاينة)',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                const Text(
                  'دي نسخة بدون باك إند أو خرائط — بس علشان تشوف الشكل العام.',
                  style: TextStyle(fontSize: 16, color: Colors.white),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 50),
                ElevatedButton(
                  onPressed: () => Navigator.pushNamed(context, '/login'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFF9800),
                    padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                  ),
                  child: const Text('سجل دخول', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ),
                const SizedBox(height: 20),
                OutlinedButton(
                  onPressed: () => Navigator.pushNamed(context, '/register'),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Colors.white),
                    padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                  ),
                  child: const Text('إنشاء حساب', style: TextStyle(fontSize: 18, color: Colors.white)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ************************** Role Selection **************************
class RoleSelectionScreen extends StatelessWidget {
  const RoleSelectionScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('اختار دورك')),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('عايز تكون إيه في التطبيق؟', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
            const SizedBox(height: 24),
            _RoleCard(
              image: 'assets/learner.png',
              title: 'طالب تعليم',
              subtitle: 'عايز تتعلم سواقة عربية أو موتوسيكل أو سكوتر',
              onTap: () => Navigator.pushNamed(context, '/learner_home'),
            ),
            const SizedBox(height: 16),
            _RoleCard(
              image: 'assets/trainer.png',
              title: 'كابتن',
              subtitle: 'عندك عربية أو موتوسيكل وعايز تدرس ناس',
              onTap: () => Navigator.pushNamed(context, '/trainer_home'),
            ),
          ],
        ),
      ),
    );
  }
}

class _RoleCard extends StatelessWidget {
  final String image, title, subtitle;
  final VoidCallback onTap;
  const _RoleCard({required this.image, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 5,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              Image.asset(image, height: 120),
              const SizedBox(height: 12),
              Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text(subtitle, textAlign: TextAlign.center),
            ],
          ),
        ),
      ),
    );
  }
}

// ************************** Learner Home **************************
class LearnerHomeScreen extends StatelessWidget {
  const LearnerHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final orders = context.watch<OrderProvider>().orders;
    return Scaffold(
      appBar: AppBar(
        title: const Text('طلبات التعليم'),
        actions: [
          IconButton(icon: const Icon(Icons.notifications), onPressed: () {}),
          IconButton(icon: const Icon(Icons.person), onPressed: () => Navigator.pushNamed(context, '/profile')),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'دور على كابتن أو نوع عربية...',
                      prefixIcon: const Icon(Icons.search),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
                      filled: true,
                      fillColor: Colors.white,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                FloatingActionButton(
                  onPressed: () => Navigator.pushNamed(context, '/learner_create_order'),
                  backgroundColor: const Color(0xFFFF9800),
                  child: const Icon(Icons.add),
                ),
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.0),
            child: Align(
              alignment: Alignment.centerRight,
              child: Text('الكباتن القريبين منك', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
          ),
          SizedBox(
            height: 180,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: 5,
              itemBuilder: (context, index) {
                return TrainerCard(
                  name: 'كابتن محمد',
                  rating: 4.8,
                  distance: 2.5,
                  vehicle: 'عربية مانيوال',
                );
              },
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.0),
            child: Align(
              alignment: Alignment.centerRight,
              child: Text('طلباتك الحديثة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: orders.length,
              itemBuilder: (context, index) {
                final order = orders[index];
                return OrderCard(order: order);
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: const BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'الرئيسية'),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: 'طلباتي'),
          BottomNavigationBarItem(icon: Icon(Icons.chat), label: 'الشات'),
        ],
      ),
    );
  }
}

// ************************** Create Order **************************
class LearnerCreateOrderScreen extends StatefulWidget {
  const LearnerCreateOrderScreen({super.key});
  @override
  State<LearnerCreateOrderScreen> createState() => _LearnerCreateOrderScreenState();
}

class _LearnerCreateOrderScreenState extends State<LearnerCreateOrderScreen> {
  String? selectedVehicleType;
  String? selectedTransmission;
  DateTime? selectedDate;
  TimeOfDay? selectedTime;

  final List<String> vehicleTypes = ['عربية', 'موتوسيكل', 'سكوتر', 'عجلة'];
  final List<String> transmissions = ['مانيوال', 'أوتوماتيك'];

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );
    if (picked != null) setState(() => selectedDate = picked);
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) setState(() => selectedTime = picked);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('طلب جديد')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('نوع العربية', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Wrap(
              spacing: 10,
              children: vehicleTypes.map((type) {
                return ChoiceChip(
                  label: Text(type),
                  selected: selectedVehicleType == type,
                  onSelected: (selected) {
                    setState(() { selectedVehicleType = selected ? type : null; });
                  },
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            const Text('نوع الفتيس', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Wrap(
              spacing: 10,
              children: transmissions.map((type) {
                return ChoiceChip(
                  label: Text(type),
                  selected: selectedTransmission == type,
                  onSelected: (selected) {
                    setState(() { selectedTransmission = selected ? type : null; });
                  },
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            const Text('موعد الحجز', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => _selectDate(context),
                    child: Text(selectedDate == null ? 'اختار التاريخ' : '${selectedDate!.year}-${selectedDate!.month}-${selectedDate!.day}'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => _selectTime(context),
                    child: Text(selectedTime == null ? 'اختار الوقت' : selectedTime!.format(context)),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            const Text('موقع التدريب', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Container(
              height: 200,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: Colors.grey),
              ),
              child: const Center(child: Text('خريطة (Placeholder بدون Google Maps)')),
            ),
            const SizedBox(height: 20),
            const Text('ملاحظات إضافية', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const TextField(
              maxLines: 3,
              decoration: InputDecoration(
                hintText: 'اكتب أي ملاحظات أو متطلبات خاصة...',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 30),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  if (selectedVehicleType != null && selectedTransmission != null) {
                    context.read<OrderProvider>().addOrder(Order(
                      title: 'حجز ${selectedVehicleType!} - ${selectedTransmission!}',
                      date: selectedDate,
                      time: selectedTime,
                    ));
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إرسال طلبك (تجريبي)')));
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF0D47A1),
                  padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                ),
                child: const Text('أرسل الطلب', style: TextStyle(fontSize: 18)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ************************** Profile **************************
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الملف الشخصي')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const CircleAvatar(radius: 60, backgroundImage: AssetImage('assets/user.png')),
            const SizedBox(height: 20),
            const Text('محمد أحمد', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            const Text('طالب تعليم', style: TextStyle(fontSize: 18, color: Colors.grey)),
            const SizedBox(height: 30),
            _buildProfileItem(Icons.person, 'تعديل البيانات الشخصية'),
            _buildProfileItem(Icons.settings, 'الإعدادات'),
            _buildProfileItem(Icons.logout, 'تسجيل الخروج'),
          ],
        ),
      ),
    );
  }

  static Widget _buildProfileItem(IconData icon, String title) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title),
        trailing: const Icon(Icons.chevron_right),
        onTap: () {},
      ),
    );
  }
}

// ************************** Trainer / Others (Placeholders) **************************
class TrainerHomeScreen extends StatelessWidget {
  const TrainerHomeScreen({super.key});
  @override
  Widget build(BuildContext context) =>
      const SimpleScaffold(title: 'صفحة الكابتن', text: 'هنا هتظهر طلبات الطلبة القريبين منك.');
}

class TrainerOrdersScreen extends StatelessWidget {
  const TrainerOrdersScreen({super.key});
  @override
  Widget build(BuildContext context) =>
      const SimpleScaffold(title: 'طلبات الكابتن', text: 'قائمة بالطلبات (تجريبية).');
}

class OrderDetailScreen extends StatelessWidget {
  const OrderDetailScreen({super.key});
  @override
  Widget build(BuildContext context) =>
      const SimpleScaffold(title: 'تفاصيل الطلب', text: 'تفاصيل الطلب (تجريبية).');
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});
  @override
  Widget build(BuildContext context) =>
      const SimpleScaffold(title: 'الإعدادات', text: 'إعدادات التطبيق.');
}

class ChatScreen extends StatelessWidget {
  const ChatScreen({super.key});
  @override
  Widget build(BuildContext context) =>
      const SimpleScaffold(title: 'الشات', text: 'المراسلات بين الطالب والكابتن (واجهة فقط).');
}

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('تسجيل الدخول')),
        body: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              TextField(decoration: InputDecoration(labelText: 'الإيميل', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
              const SizedBox(height: 12),
              TextField(obscureText: true, decoration: InputDecoration(labelText: 'الرقم السري', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
              const SizedBox(height: 12),
              SizedBox(width: double.infinity, child: ElevatedButton(onPressed: () => Navigator.pushNamed(context, '/role_selection'), child: const Text('دخول'))),
            ],
          ),
        ),
      );
}

class RegisterScreen extends StatelessWidget {
  const RegisterScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('إنشاء حساب')),
        body: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              TextField(decoration: InputDecoration(labelText: 'الاسم', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
              const SizedBox(height: 12),
              TextField(decoration: InputDecoration(labelText: 'الإيميل', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
              const SizedBox(height: 12),
              TextField(obscureText: true, decoration: InputDecoration(labelText: 'الرقم السري', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
              const SizedBox(height: 12),
              SizedBox(width: double.infinity, child: ElevatedButton(onPressed: () => Navigator.pushNamed(context, '/role_selection'), child: const Text('تسجيل'))),
            ],
          ),
        ),
      );
}

// ************************** Widgets / Models **************************
class SimpleScaffold extends StatelessWidget {
  final String title;
  final String text;
  const SimpleScaffold({super.key, required this.title, required this.text});
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text(title)), body: Center(child: Padding(padding: const EdgeInsets.all(16), child: Text(text))));
  }
}

class TrainerCard extends StatelessWidget {
  final String name; final double rating; final double distance; final String vehicle;
  const TrainerCard({super.key, required this.name, required this.rating, required this.distance, required this.vehicle});
  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(12),
      child: SizedBox(
        width: 200,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text('$rating ⭐'),
              Text('$distance كم بعيد'),
              Text(vehicle),
              const SizedBox(height: 8),
              ElevatedButton(onPressed: () {}, child: const Text('احجز')),
            ],
          ),
        ),
      ),
    );
  }
}

class Order {
  final String title;
  final DateTime? date;
  final TimeOfDay? time;
  Order({required this.title, this.date, this.time});
}

class OrderCard extends StatelessWidget {
  final Order order; const OrderCard({super.key, required this.order});
  @override
  Widget build(BuildContext context) {
    final dateText = order.date == null ? '' : ' - ${order.date!.year}/${order.date!.month}/${order.date!.day}';
    final timeText = order.time == null ? '' : ' ${order.time!.format(context)}';
    return Card(
      child: ListTile(
        title: Text(order.title + dateText + timeText),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.pushNamed(context, '/order_detail'),
      ),
    );
  }
}

class OrderProvider extends ChangeNotifier {
  final List<Order> _orders = [];
  List<Order> get orders => _orders;
  void addOrder(Order o) { _orders.add(o); notifyListeners(); }
}
